#include<string>
#include"padreCamara.h"
#include"AtributosComunes.h" 

#pragma once 
class TarjetaMemoria : public AtributosComunes, public padreCamara
{
protected: 
	int capacidad;
	
	
public:
	TarjetaMemoria();
	TarjetaMemoria(string capacidad);
	
    void setcapacidad(string lacapacidad);
	string getcapacidad(); 
}