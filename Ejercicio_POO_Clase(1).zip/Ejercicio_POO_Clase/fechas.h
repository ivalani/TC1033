#pragma once 
class fechas 
{
	protected 
		int dia
		string mes 
		int ano 
		
}; 