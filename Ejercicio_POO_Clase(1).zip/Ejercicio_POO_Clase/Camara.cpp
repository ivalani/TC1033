#include"Camara.h" 

Camara::Camara()
{
	
	
}
void Camara::setResolucion(Resolucion laResolucion)
{
	
}
Resolucion Camara::getResolucion()
{
	
}
void Camra::setFechaGrabacion(fechaGrabacion laFechaGrabacion)
{
	
}
FechaGrabacion Camara::getFechaGrabacion() 
{
	
}