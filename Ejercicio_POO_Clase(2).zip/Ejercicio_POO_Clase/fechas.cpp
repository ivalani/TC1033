#include"fechas.h" 

void fechas::setdia(int eldia)
{
	eldia = (22);
}

int fechas::getdia()
{
	return dia;
}

void fechas::setmes(string elmes)
{
	elmes = ("diciembre");
}

string fechas::getmes()
{
	return mes
}

void fechas::setano(int elano)
{
	ano = (2020);
}

int fechas::getano()
{
	return ano;
}