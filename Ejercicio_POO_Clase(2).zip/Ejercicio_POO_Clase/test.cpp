#include<iostream>
#include"Camara.h" 

using namespace std/

int main()
{
	Camara rm;
	rm.setResolucion(1000);
	
	cout<<"se desea mostra los detalles de la camara, es todo; su resolucion es" << rm.getResolucion();
	
}