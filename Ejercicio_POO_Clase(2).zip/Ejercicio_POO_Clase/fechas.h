#pragma once 
class fechas 
{
	protected:
		int dia
		string mes 
		int ano 
	public:	
	   void setdia(int eldia);
	   int getdia();
	   void setmes(string elmes);
	   string getmes();
	   void setano(int elano);
	   int getano();
}; 