#include"TarjetaMemoria.h" 


TarjetaMemoria::TarjetaMemoria()
{
	Capacidad = 1000;
}
TarjetaMemoria::TarjetaMemoria(int capacidad)
{
	Capacidad = lacapacidad;
}
void TarjetaMemoria::setcapacidad(int lacapacidad)
{
	Capacidad = lacapacidad
}
int TarjetaMemoria::getcapacidad()
{
	return Capacidad; 
}